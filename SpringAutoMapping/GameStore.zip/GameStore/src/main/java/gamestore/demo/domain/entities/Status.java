package gamestore.demo.domain.entities;

public enum Status {
    ADMIN, USER;
}
